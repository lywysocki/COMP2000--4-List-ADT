If you have any data files for your game, they must go in this folder.

To access any files here, you must reference them using a relative path - for example, the path
to this file must be "./data/readme.txt"